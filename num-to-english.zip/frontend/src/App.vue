<template>
  <v-app>
    <v-container class="fill-height d-flex justify-center align-center">
      <NumberConverter />
    </v-container>
  </v-app>
</template>

<script setup>
import NumberConverter from './components/NumberConverter.vue';
</script>