<script setup lang="ts">
import NumberConverter from "../components/NumberConverter.vue";
</script>

<template>
  <main>
    <NumberConverter />
  </main>
</template>
